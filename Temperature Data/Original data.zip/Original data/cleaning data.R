setwd("~/Desktop/ENV 810/Data/Temp")

library(dplyr)
library(stringr)

csvs <- dir()[str_detect(dir(),".csv")]

final <- data.frame()
for(i in 1:length(csvs)){
  temp <- read.csv(csvs[i])
  zone <- str_extract_all(csvs[i], "zone [0-9]+")
  zone <- as.integer(str_extract_all(zone, "[0-9]+"))
  temp <- select(temp, month, day, hour, HLY.TEMP.NORMAL)
  temp$zone <- zone
  final <- rbind(final, temp)
  print(zone)
}

## add zone 3, which is a simple mean of zone 6 and zone 2
zone6 <- filter(final, zone == 6)
zone2 <- filter(final, zone == 2)
zone3 <- zone2
zone3$HLY.TEMP.NORMAL <- (zone2$HLY.TEMP.NORMAL+zone6$HLY.TEMP.NORMAL)/2
zone3$zone <- 3

## export final
final <- write.csv(final, "2020 15 year temp normals in WI by 11 HDD zones.csv", row.names = F)
